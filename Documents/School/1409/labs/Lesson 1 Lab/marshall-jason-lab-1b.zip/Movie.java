/**
 * This class describes a movie
 * @author Jason Marshall
 * @version 1.0
*/
class Movie
{
    private String  title;
    private int     productionYear;
    private double  durationMinute;
    private boolean color;
    
       
    
}
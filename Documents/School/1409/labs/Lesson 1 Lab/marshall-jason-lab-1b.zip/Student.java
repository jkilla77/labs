/**
 * This class describes a student
 * @author Jason Marshall
 * @version 1.0
*/
class Student
{
    private String  firstName;
    private String  lastName;
    private int     yearBorn;
    private double  GPA;
    private boolean forigenStudent;
    private char    sex;
       
    
}
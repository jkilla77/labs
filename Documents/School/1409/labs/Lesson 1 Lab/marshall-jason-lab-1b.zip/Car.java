/**
 * This class describes a car
 * @author Jason Marshall
 * @version 1.0
*/
class Car
{
    private String  VIN;
    private int     modelYear;
    private double  engineDisplacementLiters;
    private boolean domestic;
    private char    transmissionType;
       
    
}